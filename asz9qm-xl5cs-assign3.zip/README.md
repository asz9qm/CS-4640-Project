﻿# CS-4640-Project

Database Set up
Open XAMPP, create database name as cs4640_project
Go to user accounts, go to your user and edit privileges, go to Database
  Add privileges on the follow database:cs4640_project
  Check all and click go
  Go to connect-db.php and enter all credentials

Then go to allActions.php and uncomment out the lines at the end
  Access allActions.php in your browser, click the button
  And then go back to the file allActions.php and recomment the lines

Context: Major + School requirements 
  College Scheduler by Semester

1. Schedule

>- visual interface
  
2. Class Recommendations

>- Drop down menu 
  
3. Account management

4. Drag and Drop

5. Transcript element

>- GPA calculation
  
6. Allow term management/Personalization
